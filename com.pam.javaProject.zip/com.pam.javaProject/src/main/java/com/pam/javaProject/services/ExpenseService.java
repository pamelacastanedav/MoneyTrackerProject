package com.pam.javaProject.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pam.javaProject.models.Expense;
import com.pam.javaProject.repositories.ExpenseRepository;


@Service
public class ExpenseService {
	@Autowired
	ExpenseRepository expenseRepository;
	// creates an expense
		public Expense createExpense(Expense e) {
			return expenseRepository.save(e);
		}

	//ReadOne
		public Expense findExpense(Long id) {
			Optional<Expense> optionale = expenseRepository.findById(id);
			if (optionale.isPresent()) {
				return optionale.get();
			} else {
				return null;
			}
		}

		// Read All
		// returns all the expenses
		public List<Expense> allExpenses() {
			return expenseRepository.findAll();
		}

		// Update
		public Expense updateExpense(Expense expense) {
			return expenseRepository.save(expense);
		}

		// Delete
		public void deleteExpense(Long id) {
			expenseRepository.deleteById(id);
		}

}
