package com.pam.javaProject.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.pam.javaProject.models.Expense;
import com.pam.javaProject.models.LoginUser;
import com.pam.javaProject.models.User;
import com.pam.javaProject.services.ExpenseService;
import com.pam.javaProject.services.UserService;



@Controller
public class HomeController {
	@Autowired
    private UserService userServ;
	@Autowired
	private ExpenseService expenseService;
    
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("newUser", new User());
        model.addAttribute("newLogin", new LoginUser());
        return "index.jsp";
    }
    
    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("newUser") User newUser, 
            BindingResult result, Model model, HttpSession session) {
        userServ.register(newUser, result);
        if(result.hasErrors()) {
            model.addAttribute("newLogin", new LoginUser());
            return "index.jsp";
        }
        session.setAttribute("user_id", newUser.getId());
        return "redirect:/homepage";
    }
    
    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
            BindingResult result, Model model, HttpSession session) {
        User user = userServ.login(newLogin, result);
        if(result.hasErrors()) {
            model.addAttribute("newUser", new User());
            return "index.jsp";
        }
        session.setAttribute("user_id", user.getId());
        return "redirect:/homepage";
    }
    
    //Dashboard
    //READ ALL
    @RequestMapping("/homepage")
    public String homePage(@ModelAttribute("expense") Expense expense, Model model, HttpSession session) {
		// retrieve user from session
		Long userId = (Long) session.getAttribute("user_id");
		// Retrieve user and check if not null
		if (userId == null) {
			return "redirect:/";
		} else {
			// retrieve user from database
			User thisUser = userServ.findUserById(userId);
			// pass user object to the page
			model.addAttribute("thisUser", thisUser);
			List<Expense> allExpenses = expenseService.allExpenses();
			model.addAttribute("expenses", allExpenses);
			Integer sum = 0;
			for(Expense e: allExpenses) {
				sum += e.getAmount();
			}
			model.addAttribute("sum",sum);
			
			//calculate sum and add it to model attribute
			return "homepage.jsp";
		}
		}
		
		//Create expense
		@GetMapping("/expense/new")
		public String create (@ModelAttribute("expense")Expense expense,Model model, HttpSession session) {
			return "CreateExpense.jsp";
		
}
		@PostMapping("/expense/new")
		public String createExpense(@Valid @ModelAttribute("expense") Expense expense, BindingResult result, Model model,
				HttpSession session) {
			if (result.hasErrors()) {

				return "CreateExpense.jsp";
			} else {

				expenseService.createExpense(expense);
				return "redirect:/homepage";
			}
		}
		// READ ONE
		@RequestMapping("expense/show/{id}")
		public String readOne(@PathVariable("id") Long id, Model model) {
			Expense OneExpense = expenseService.findExpense(id);
			// pass variable,value
			model.addAttribute("expense", OneExpense);
			return "OneExpense.jsp";
		}

		// Edit
		@GetMapping("/expense/edit/{id}")
		public String edit(@Valid @PathVariable("id") Long id, Model model, HttpSession session) {
			Expense expenses = expenseService.findExpense(id);
			model.addAttribute("expense", expenses);
			Long userId = (Long) session.getAttribute("user_id");
			if (userId == null)
				return "redirect:/";
			return "EditExpense.jsp";
		}

		@PutMapping("/expense/edit/{id}")
			public String editExpense(@Valid @ModelAttribute("expense") Expense expense, Model model, BindingResult result,
					HttpSession session) {
			
				if (result.hasErrors()) {

					return "EditExpense.jsp";
				} else {
					
					expenseService.updateExpense(expense);
					return "redirect:/homepage";
				}
		}
		//DELETE
		@RequestMapping(value="/expense/delete/{id}", method=RequestMethod.DELETE)
		public String delete(@PathVariable("id") Long id) {
			expenseService.deleteExpense(id);
			return "redirect:/homepage";
		}
}